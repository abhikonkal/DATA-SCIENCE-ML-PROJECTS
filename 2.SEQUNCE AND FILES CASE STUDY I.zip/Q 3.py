print("enter a number in the range(1000,3000")

s = input()


for i in range(1000,3000) :
    if int(s[0])%2 == 0:
        if int(s[1])%2 == 0:
            if int(s[2])%2 == 0:
                if int(s[3])%2 == 0:
                    print(s[0],"-",s[1],"-",s[2],"-",s[3],)
                    break