print("Enter the string :")
raw_string = input()

words = [word.lower() for word  in raw_string.split()]

words.sort()

print ("the words in alphabetiocal order are:")
for word in words:
   print(word)
