a = int(input("Enter any number \n"))
print("The factors of",a,"are:")
for i in range(1, a+ 1):
    if a % i == 0:
        if i % 2 == 0:
            print(i," Even")
        else:
            print(i," Odd")