print('Enter number')

n = input()

a = n[::-1]

if n==a :
    print("the given number is palindrome")
else :
    print("the given number is not palindrome")