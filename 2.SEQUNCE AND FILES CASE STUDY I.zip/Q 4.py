print("enter sentence:")

n = input()
num = 0 
alphabet = 0

for i in n:
    if i.isdigit():
        num=num+1
    elif i.isalpha():
        alphabet=alphabet+1
    else :
        pass
print("no of digits are :",num)

print("no of alphabets are :",alphabet)

    
